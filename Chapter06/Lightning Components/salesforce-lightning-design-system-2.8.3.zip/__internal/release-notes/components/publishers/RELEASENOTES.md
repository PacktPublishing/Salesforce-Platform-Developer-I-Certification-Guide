<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Publishers Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Fixed

- Made the publisher label visible to screen readers in the collapsed state of a publisher, by removing the use of `display: none`
