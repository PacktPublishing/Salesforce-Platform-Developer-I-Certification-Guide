<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Expression Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Added new Expression component to help users declaratively construct logical expressions
