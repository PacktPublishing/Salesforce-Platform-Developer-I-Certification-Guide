<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Color Picker Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
