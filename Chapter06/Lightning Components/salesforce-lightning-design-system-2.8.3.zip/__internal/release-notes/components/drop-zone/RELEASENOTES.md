<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Drop Zone Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Added new Drop Zone component to help construct a drag and drop screen building experience
