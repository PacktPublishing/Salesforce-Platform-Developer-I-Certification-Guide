<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Pills Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
