<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Radio Group Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Added an example of a checked-and-disabled radio button.
