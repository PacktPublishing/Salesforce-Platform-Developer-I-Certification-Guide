<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Docked Utility Bar Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
