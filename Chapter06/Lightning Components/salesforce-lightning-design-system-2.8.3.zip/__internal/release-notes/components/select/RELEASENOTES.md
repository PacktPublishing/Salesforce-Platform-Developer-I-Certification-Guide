<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Select Release Notes

<!-- ## [Unreleased] -->

## 2.8.4

### Fixed
- Adjusted pseudo elements to allow click events to pass through
