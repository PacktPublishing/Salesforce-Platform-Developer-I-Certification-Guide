<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Map Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Added a standalone map example that lives outside of a modal

### Fixed

- Replaced inline styles from `iframe` and placed them within the component styling
- Improved the color contrast of links inside of selected items in the locations list
