<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Expandable Section Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Changed
- Replaced spacing tokens with variable spacing tokens to respond to a user's densification setting
