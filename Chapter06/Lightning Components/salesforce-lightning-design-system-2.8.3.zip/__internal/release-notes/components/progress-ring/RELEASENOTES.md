<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Progress Ring Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Added an example of a progress ring that fills rather than drains, meaning the colored portion of the ring increases clockwise.
