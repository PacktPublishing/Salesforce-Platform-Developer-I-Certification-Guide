<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Progress Bar Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Updated the documentation for vertical progress bars. Now you can actually see it, yay!
