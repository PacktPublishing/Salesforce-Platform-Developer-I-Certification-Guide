<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Input Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Fixed
- Resolved issue where `slds-input__icon_left` and `.slds-input__icon` elements were positioned over labels when in horizontal form elements
