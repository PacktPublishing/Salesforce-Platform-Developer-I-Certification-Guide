<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Dynamic Icons Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
