<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Tooltips Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Added
- Added examples for tooltip triggered by links, buttons, and inputs
