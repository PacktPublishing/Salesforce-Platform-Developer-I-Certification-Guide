<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Avatar Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Changed
- Changed HTML so the Avatar component can be slotted inside of an `href` vs being the `href` element
