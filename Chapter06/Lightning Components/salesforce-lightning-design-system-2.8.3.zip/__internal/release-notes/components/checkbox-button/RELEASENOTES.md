<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Checkbox Button Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Added an example of a checked-and-disabled checkbox button.

### Fixed

- Increased the contrast between the plus symbol and background color for the disabled checkbox button.
