<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Breadcrumbs Release Notes

<!-- ## [Unreleased] -->
## 2.8.4

### Fixed
- Adjusted typographic styling for breadcrumb items.

## 2.8.0

### Changed

- Added bold font weight to '.slds-breadcrumb__item`.

### Removed

- Removed `.slds-text-title_caps` from breadcrumb list item.
