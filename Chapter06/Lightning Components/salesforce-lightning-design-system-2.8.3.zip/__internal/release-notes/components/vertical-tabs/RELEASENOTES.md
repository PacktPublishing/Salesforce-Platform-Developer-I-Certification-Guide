<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Vertical Tabs Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Added
- Added examples of icons in vertical tabs
- Added examples of badges in vertical tabs
- Added new classes to support icons and badges, `slds-vertical-tabs__left-icon` and `slds-vertical-tabs__right-icon`
