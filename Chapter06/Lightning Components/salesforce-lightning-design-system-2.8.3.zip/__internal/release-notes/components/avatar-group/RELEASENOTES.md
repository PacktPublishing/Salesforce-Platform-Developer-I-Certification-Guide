<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Avatar Group Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Added

- Added a new blueprint and docs for Avatar Group component that is used for communicating to users that more than one person is associated with an item.
