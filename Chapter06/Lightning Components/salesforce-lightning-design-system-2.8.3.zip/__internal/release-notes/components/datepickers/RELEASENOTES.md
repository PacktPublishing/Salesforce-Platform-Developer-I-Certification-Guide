<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Datepickers Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
