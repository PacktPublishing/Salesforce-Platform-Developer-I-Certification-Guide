<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# File Selector Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Changed

- Replaced spacing tokens with variable spacing tokens to respond to a user's densification setting
- Reduced height to minimize whitespace
