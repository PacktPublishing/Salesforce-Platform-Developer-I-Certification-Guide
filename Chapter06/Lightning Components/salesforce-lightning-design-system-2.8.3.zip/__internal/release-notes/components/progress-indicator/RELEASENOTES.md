<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Progress Indicator Release Notes

<!-- ## [Unreleased] -->

## 2.8.1

### Fixed

- IE11: Layout issues when in a modal
