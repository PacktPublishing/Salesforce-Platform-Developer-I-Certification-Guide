<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Menus Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Added

- 3 levels of status for menu items to alert the user - error, success, and warning

### Changed

- Increased font size to 14px applied bold font weight in `slds-dropdown__header`.

### Removed

- Removed `slds-text-title_caps` from menu sub headers.
