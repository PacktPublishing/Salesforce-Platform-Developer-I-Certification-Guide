<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Checkbox Toggle Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
