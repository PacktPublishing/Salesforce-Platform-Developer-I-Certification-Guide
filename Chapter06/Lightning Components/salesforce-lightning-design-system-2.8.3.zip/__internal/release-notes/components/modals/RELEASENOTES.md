<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Modals Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
