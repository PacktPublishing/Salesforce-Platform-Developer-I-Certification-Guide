<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Path Simple Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
