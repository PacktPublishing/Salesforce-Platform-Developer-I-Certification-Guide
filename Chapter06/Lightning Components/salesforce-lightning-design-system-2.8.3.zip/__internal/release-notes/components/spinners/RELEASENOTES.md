<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Spinners Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
