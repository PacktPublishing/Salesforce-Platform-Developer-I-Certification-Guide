<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Global Header Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Removed

- Removed `slds-text-title_caps` from menu headers.

## 2.7.0

### Changed

- Changed Salesforce logo image path.
