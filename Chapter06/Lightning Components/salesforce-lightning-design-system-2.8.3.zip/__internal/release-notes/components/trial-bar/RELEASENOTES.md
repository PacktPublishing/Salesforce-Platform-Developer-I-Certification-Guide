<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Trial Bar Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Fixed

- Buttons with the new BEM syntax used within an inverse themed component no longer have their text color overridden
