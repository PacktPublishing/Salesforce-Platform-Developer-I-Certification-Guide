<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Visual Picker Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Changed

- Updated disabled visual picker UI to be more apparent and better match established conventions for disabled UI
