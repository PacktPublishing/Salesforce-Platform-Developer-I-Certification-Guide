<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Docked Form Footer Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
