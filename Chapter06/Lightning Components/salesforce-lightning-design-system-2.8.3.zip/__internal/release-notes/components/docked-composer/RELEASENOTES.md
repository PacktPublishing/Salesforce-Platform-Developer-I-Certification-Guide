<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Docked Composer Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
