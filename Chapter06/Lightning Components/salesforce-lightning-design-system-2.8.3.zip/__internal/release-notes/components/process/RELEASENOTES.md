<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Process Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Fixed

### Removed

- Removed `slds-text-title_caps` from wizard labels.
