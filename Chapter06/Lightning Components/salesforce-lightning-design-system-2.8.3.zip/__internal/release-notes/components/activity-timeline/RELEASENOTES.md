<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Activity Timeline Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
