<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Picklist Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Added

- Added `slds-listbox__option-header` to increase font size to 14px, and apply bold font weight, on listbox option headers.

### Removed

- Removed `slds-text-title_caps` from listbox option headers.
