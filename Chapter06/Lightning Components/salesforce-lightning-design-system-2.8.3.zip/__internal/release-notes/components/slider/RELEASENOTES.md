<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Slider Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Fixed

- Fixed a bug that prevented Slider background from appearing in IE11.
