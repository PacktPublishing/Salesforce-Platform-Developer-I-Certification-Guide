<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Illustration Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added

- Added example for large illustrations
