<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Button Icons Release Notes

<!-- ## [Unreleased] -->

## 2.8.0

### Added

- Added support for disabled stateful button icons

## 2.7.0

### Added

- Added a title and assistive text to most button icon examples
