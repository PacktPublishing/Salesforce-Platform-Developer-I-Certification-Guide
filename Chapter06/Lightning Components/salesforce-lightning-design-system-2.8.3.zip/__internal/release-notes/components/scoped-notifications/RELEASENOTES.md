<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Scoped Notifications Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
