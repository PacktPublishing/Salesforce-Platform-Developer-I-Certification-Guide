<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Name Value List Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
