<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Hyphenation Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
