<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Truncation Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
