<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Padding Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->

## 2.8.0

### Added

- Added documentation detailing the values of the variable density classes in Comfy and Compact modes
