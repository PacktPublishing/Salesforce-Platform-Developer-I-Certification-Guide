<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Text Utility Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Added
- Added text color utility class, `slds-text-color_destructive`, for destructive actions
