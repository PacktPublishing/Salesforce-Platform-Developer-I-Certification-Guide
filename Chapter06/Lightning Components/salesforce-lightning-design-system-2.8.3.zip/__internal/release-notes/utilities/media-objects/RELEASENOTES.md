<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Media Objects Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
