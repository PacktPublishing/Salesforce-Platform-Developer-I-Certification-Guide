<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Floats Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
