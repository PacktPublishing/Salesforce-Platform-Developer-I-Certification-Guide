<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Description List Utilities Release Notes

<!-- ## [Unreleased] -->

## 2.7.0

### Changed
- Changed behavior of media query when `slds-dl_horizontal` and `slds-dl_inline` are located inside of `slds-region_narrow`
