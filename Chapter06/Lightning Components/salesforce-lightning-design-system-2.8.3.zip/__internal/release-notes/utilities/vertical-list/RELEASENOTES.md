<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Vertical List Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
