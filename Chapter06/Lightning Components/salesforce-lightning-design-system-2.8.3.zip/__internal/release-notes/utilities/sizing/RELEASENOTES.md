<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Sizing Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
