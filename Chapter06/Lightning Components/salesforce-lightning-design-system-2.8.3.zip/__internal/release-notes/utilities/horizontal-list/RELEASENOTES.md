<!-- Release notes authoring guidelines: http://keepachangelog.com/ -->

# Horizontal List Utility Release Notes

<!-- ## [Unreleased] -->

<!-- ## [VERSION] -->
